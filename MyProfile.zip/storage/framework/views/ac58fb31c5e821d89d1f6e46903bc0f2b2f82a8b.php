<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <title>Document</title>
</head>
<body>
<div class="container">
    <div class="msg_list">
        <div class="row msg_header">
            <div class="col-2 msg_home">
                <a href="/">Home</a>
            </div>
            <div class="col-10 msg-content">
                <h3>Message List</h3>
            </div>
        </div>

        <table class="table table-bordered">
            <thead>
            <tr>
                <th scope="col">S/N</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Message</th>
            </tr>
            </thead>
            <tbody>
            <?php $i = 1 ?>
            <?php $__currentLoopData = $msg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($m->name); ?></td>
                    <td><?php echo e($m->email); ?></td>
                    <td><?php echo e($m->message); ?></td>
                </tr>
                <?php $i++ ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    </div>
</div>

</body>
</html>
<?php /**PATH D:\Apache\htdocs\Project\MyProject\MyProfile\resources\views/messages.blade.php ENDPATH**/ ?>